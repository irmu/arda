v0.0.20
- fix weatherbit

v1.0.19
- fix yahoo weather again

v1.0.18
- fixed en_gb/strings.po translation

v1.0.17
- fix yahoo weather again

Fork
v0.0.16
- fix yahoo weather again

v0.0.15
- bump for repo release

v0.0.14
- fix yahoo weather again

v0.0.13
- fix yahoo weather again

v1.0.12
- merge weather.multi fork changes and apply to providers
- fork changes for Yahoo crumb issue

v1.0.4
- correct issue with millisecond timestamp conversion on raspberry pi  

v1.0.3
- modularize new providers

v.0.0.2
- revert wunderground pws search location to city with list of nearby stations
- added non-documented \_DELETE\_ for location deletion - DEBUGGING USE ONLY 

v0.0.1
- added wunderground and ambientweather providers
_________________________
Original Repo  
v0.0.6
- fix yahoo weather

v0.0.5
- fix crash when precipitation data is missing

v0.0.4
- fix location search
- fix yahoo daily weather

v0.0.3
- fix maps

v0.0.2
- refactor code

v0.0.1
- initial release
