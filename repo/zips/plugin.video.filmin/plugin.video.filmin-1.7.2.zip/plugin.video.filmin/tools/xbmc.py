# pylint: skip-file

ISO_639_1 = 0


def getLanguage(format: int = 0, region: bool = False) -> str:
    return "es_ES"
