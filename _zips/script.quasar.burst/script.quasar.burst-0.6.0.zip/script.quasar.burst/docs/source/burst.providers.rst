burst.providers package
=======================

.. automodule:: burst.providers
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

burst.providers.definitions module
----------------------------------

.. automodule:: burst.providers.definitions
    :members:
    :undoc-members:
    :show-inheritance:


