class BTFailure(Exception):
    pass
