# -*- coding: utf-8 -*-
#######################################################################
 # ----------------------------------------------------------------------------
 # "THE BEER-WARE LICENSE" (Revision 42):
 #  As long as you retain this notice you can do whatever you want with this
 # stuff. Just please ask before copying. If we meet some day, and you think
 # this stuff is worth it, you can buy me a beer in return. - Muad'Dib
 # ----------------------------------------------------------------------------
#######################################################################

# Addon Name: Atreides
# Addon id: plugin.module.atreides
# Addon Provider: House Atreides