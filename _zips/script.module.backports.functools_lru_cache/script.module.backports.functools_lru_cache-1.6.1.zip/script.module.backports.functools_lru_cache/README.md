# script.module.backports.functools_lru_cache

Backport of functools.lru_cache from Python 3.3 packed for Kodi.

See https://github.com/jaraco/backports.functools_lru_cache
