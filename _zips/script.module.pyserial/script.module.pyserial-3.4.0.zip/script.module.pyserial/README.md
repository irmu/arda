# script.module.pyserial
pyserial library packed for Kodi

pyserial from https://github.com/pyserial/pyserial
